// Language List
const languages = {
    "en-US": "English",
    "hi-IN": "Hindi",
    "te-IN": "Telugu",
    "ta-IN": "Tamil",
    "kn-IN": "Kannada",
    "ml-IN": "Malayalam",
    "zh-CN": "Chinese",
    "es-ES": "Spanish",
    "fr-FR": "French",
    "de-DE": "German"
};

const inputSelect = document.getElementById("inputLang");
const outputSelect = document.getElementById("outputLang");

// Populate dropdowns
for (let code in languages) {
    inputSelect.innerHTML += `<option value="${code}">${languages[code]}</option>`;
    outputSelect.innerHTML += `<option value="${code}">${languages[code]}</option>`;
}

// Speech Recognition
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.continuous = false;
recognition.interimResults = false;

let voices = [];

// Properly Load Voices
function loadVoices() {
    voices = speechSynthesis.getVoices();
}
loadVoices();
speechSynthesis.onvoiceschanged = loadVoices;

// Start Button
document.getElementById("startBtn").addEventListener("click", () => {
    recognition.lang = inputSelect.value;
    recognition.start();
});

// When Speech Recognized
recognition.onresult = async (event) => {

    const spokenText = event.results[0][0].transcript;
    document.getElementById("recognizedText").innerText = spokenText;

    const targetLangShort = outputSelect.value.split("-")[0];

    // Translate
    const response = await fetch(
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLangShort}&dt=t&q=${encodeURIComponent(spokenText)}`
    );

    const data = await response.json();
    const translatedText = data[0][0][0];

    document.getElementById("translatedText").innerText = translatedText;

    // Small delay ensures voices are ready
    setTimeout(() => {
        speakText(translatedText, outputSelect.value);
    }, 500);
};

// 🔊 SPEAK FUNCTION (Guaranteed Execution)
function speakText(text, langCode) {

    if (!text) return;

    // Stop previous speech
    speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);

    utterance.lang = langCode;
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;

    // Try exact match first
    let voice = voices.find(v => v.lang === langCode);

    // If not found, match first 2 letters (ex: 'te')
    if (!voice) {
        const shortLang = langCode.substring(0,2);
        voice = voices.find(v => v.lang.startsWith(shortLang));
    }

    if (voice) {
        utterance.voice = voice;
    }

    speechSynthesis.speak(utterance);
}